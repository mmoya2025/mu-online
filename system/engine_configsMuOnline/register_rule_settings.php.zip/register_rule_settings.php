<?php
$mvcore['reg_rule_file'] = "<p><span style="color: #ff0000;">1 - Objetivo:&nbsp;</span></p>
<p>&nbsp; &nbsp; &nbsp; El servidor Mu Oxes es totalmente gratuito, hecho para el disfrute de todos.</p>
<p>&nbsp; &nbsp; &nbsp; Si deseas colaborar y ayudar al Servidor Mu Oxes ,puedes hacerlo mediante donaciones en nuestra Tienda.</p>
<p>&nbsp;</p>
<p><span style="color: #ff0000;">2 - Esta Totalmente Proh&iacute;bido:&nbsp;</span></p>
<p>&nbsp; &nbsp; &nbsp; &bull; Usar el comando /post para divulgar webs o servidores.&nbsp;</p>
<p>&nbsp; &nbsp; &nbsp; &bull; Emitir Injurias, Calumnias.&nbsp;</p>
<p>&nbsp; &nbsp; &nbsp; &bull; Difamar o insultar severamente a un usuario o a nuestra comunidad</p>
<p>&nbsp; &nbsp; &nbsp; &bull; Hacer flood con el comando /post.&nbsp;</p>
<p>&nbsp; &nbsp; &nbsp; &bull; Env&iacute;ar mensajes referentes a sexo, drogas, apologia al crimen, o como sea cualquier mensaje que posea contenido ilegal.&nbsp;</p>
<p>&nbsp; &nbsp; &nbsp; &bull; Usar cualquier tipo de programas cheats/hackers.</p>
<p>&nbsp; &nbsp; &nbsp; &bull; Alterar el cliente de forma no oficial</p>
<p>&nbsp; &nbsp; &nbsp; &bull; Fingir ser miembro del Staff de Administraci&oacute;n Mu Oxes.&nbsp;</p>
<p>&nbsp; &nbsp; &nbsp; &bull; Irrespetar a los miembros del Staff de Administraci&oacute;n Mu Oxes &oacute; a otros Jugadores.&nbsp;</p>
<p>&nbsp; &nbsp; &nbsp; &bull; Estafa directa o indirecta por parte de un usuario</p>
<p>&nbsp; &nbsp; &nbsp; Nota: El uso de cualquier tipo de trampa, acarreara que su cuenta quede bloqueada permanentemente.&nbsp;</p>
<p>&nbsp;</p>
<p><span style="color: #ff0000;">3 - No se permite:&nbsp;</span></p>
<p>&nbsp; &nbsp; &nbsp; &bull; Pedir Items a los miembros del Staff de Administraci&oacute;n Mu Oxes.&nbsp;</p>
<p>&nbsp; &nbsp; &nbsp; &bull; Pedir Party a los miembros del Staff de Administraci&oacute;n Mu Oxes.&nbsp;</p>
<p>&nbsp; &nbsp; &nbsp; &bull; Pedir Zen a los miembros del Staff de Administraci&oacute;n Mu Oxes.&nbsp;</p>
<p>&nbsp; &nbsp; &nbsp; Nota: Los Items Gratuitos ser&aacute;n dados a los jugadores como premio en los eventos realizados</p>
<p>&nbsp; &nbsp; &nbsp; por miembros del Staff de Administraci&oacute;n Mu Oxes.&nbsp;</p>
<p>&nbsp;</p>
<p><span style="color: #ff0000;">4 - No es Responsabilidad del Servidor Mu Oxes:&nbsp;</span></p>
<p>&nbsp; &nbsp; &nbsp; &bull; Articulos robados a los usuarios por el uso indebido de las opciones y/o herramientas del Juego.&nbsp;</p>
<p>&nbsp; &nbsp; &nbsp; &bull; Negociaci&oacute;n de Items, Cuentas, Zen, Personajes, entre otros dentro del Servidor Mu Oxes.&nbsp;</p>
<p>&nbsp; &nbsp; &nbsp; &bull; Da&ntilde;os a la Cuenta y/o Personajes realizado por los usuarios por impericia en el Juego.&nbsp;</p>
<p>&nbsp; &nbsp; &nbsp; &bull; Estafas o perjuicios a la Cuenta y/o Personajes dentro del Servidor Mu Oxes. (A excepcion de presentar pruebas)</p>
<p>&nbsp;</p>
<p><span style="color: #ff0000;">5 - Donaciones / Dep&oacute;sitos / Compras:</span></p>
<p>&nbsp; &nbsp; &nbsp; &bull; Todos los dep&oacute;sitos realizados en las Cuentas Bancarias disponibles en la Web del Servidor Mu Oxes,</p>
<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;ser&aacute;n consideradas como "DONACIONES" al Servidor Mu Oxes. y bajo ningun concepto sera una compra. Las donaciones</p>
<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;mantienen el servidor funcional</p>
<p>&nbsp; &nbsp; &nbsp; &bull; Ning&uacute;n dep&oacute;sito o donacion ser&aacute; devuelto al usuario, ya que estos fondos se usan con y para el servidor.&nbsp;</p>
<p>&nbsp; &nbsp; &nbsp; &bull; Los Items o golds comprados al Servidor Mu Oxes ser&aacute;n responsabilidad absoluta del usuario.&nbsp;</p>
<p>&nbsp;</p>
<p><span style="color: #ff0000;">6 - Devoluci&oacute;n de Items:</span></p>
<p>&nbsp; &nbsp; &nbsp; &bull; El Servidor Mu Oxes solo se hara responsable por los Items o Cash comprados mediante donaciones,</p>
<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;y que por falla fortuita del Servidor hallan sido borrados o Bugeados.&nbsp;</p>
<p>&nbsp;</p>
<p><span style="color: #ff0000;">7 - Perdida de la Clave de Acceso:</span></p>
<p>&nbsp; &nbsp; &nbsp; &bull; En caso de Olvido o perdida de su clave, la web posee una herramienta para su recuperaci&oacute;n. Si no pone el correo correcto</p>
<p>&nbsp; &nbsp; &nbsp; &nbsp; Su clave no sera devuelta por ningun miembro del staff&nbsp;</p>
<p>&nbsp;</p>
<p><span style="color: #ff0000;">8 - Bloqueo de acceso al Servidor:</span></p>
<p>&nbsp; &nbsp; &nbsp; &bull; El usuario que incurra en una falta a las nomras antes expuestas, podran ser sancionados de la siguientes formas:</p>
<p>&nbsp; &nbsp; &nbsp; Bloqueo Parcial: Esto puede suceder si la falta no se considera muy grave o es de menor relevancia.&nbsp;</p>
<p>&nbsp; &nbsp; &nbsp; Bloqueado permanentemente: Esto puede suceder si la falta se considera muy grave o es mucha relevancia,</p>
<p>&nbsp; &nbsp; &nbsp; Exilio: Expulsion del usuario cuyas faltas percistentes califique como amenaza en nuestro server</p>
<p>&nbsp;</p>
<p><span style="color: #ffffff; background-color: #ff0000;">Estas reglas estan en constante cambio y podran ser alteradas, editadas o eliminadas por miembros del staff sin aviso previo.</span></p>
<p><span style="color: #ffffff; background-color: #ff0000;">Al ingresar a nuestras instalaciones usted afirma y acepta estas reglas y el desconocimiento de las mismas no apela la falta</span></p>";
?>